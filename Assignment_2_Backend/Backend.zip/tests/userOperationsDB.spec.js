// TESTS IN PROCESS. NOT TO BE CONSIDERED FOR ASSIGNMENT 2

const userController = require("../controller/userController")

describe("Tests for user CRUD operatiosn ", ()=>{

    test("Create a user and check the reponse", function(){
        userCreationObj = {
                "emailId": "test12@test.com",
                "password": "password@123",
                "username":"T r",
                "dob" : "12/10/1921"
        }
    })

})